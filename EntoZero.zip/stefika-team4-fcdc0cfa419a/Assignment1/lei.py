# -*- coding: utf-8 -*-
"""
Created on Tue Feb  1 17:44:58 2022

@author: Zhuohong Lei
"""

print("hello world")

