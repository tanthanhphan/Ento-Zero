//Yazmin Martinez
//CS 472/672
//Assignment 1: Practice Using Git

#include <stdio.h>
int main() {
   printf("Hello World!\n");
   return 0;
}
