#include <iostream>

//Jose Sison CS472
//Git Assignment

int main()
{
	std::cout << "Hello World\n";
	return 0;
}